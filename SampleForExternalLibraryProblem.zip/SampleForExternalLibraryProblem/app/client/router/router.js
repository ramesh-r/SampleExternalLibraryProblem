// Configure the router here
Router.configure({
  layoutTemplate: 'applicationLayout'
});

// Here we defined the default route of the application
Router.route('/login', function(){
    this.render("login", {to: 'content'});
},{name:'login'});

// Here we defined the default route of the application
Router.route('/home', function(){
    this.render("dashboard", {to: 'content'});
},{name:'default'});

// Here we defined the default route of the application
Router.route('/page1', function(){
    this.render("page1", {to: 'content'});
},{name:'page1'});

// Here we defined the default route of the application
Router.route('/page2', function(){
    this.render("page1", {to: 'content'});
},{name:'page2'});


checkUserLoggedIn = function(){
  if( !Meteor.loggingIn() && !Meteor.user() ) {
    Router.go('/login');
  } else {
    this.next();
  }
}

userAuthenticated = function(){
  if( !Meteor.loggingIn() && Meteor.user() ){
    Router.go('/home');
  } else {
    this.next();
      $('html,body').scrollTop(0);
  }
}

Router.onBeforeAction(checkUserLoggedIn, {
  except: [
    'login'
  ]
});

Router.onBeforeAction(userAuthenticated, {
  only: [
     'login',
   ]
});
