Template.page1.onRendered(function(){
  // alert('Page1');
});
