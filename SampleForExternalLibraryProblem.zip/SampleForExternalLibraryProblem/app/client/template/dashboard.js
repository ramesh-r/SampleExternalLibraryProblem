Template.dashboard.onRendered(function(){
  debugger;
  // collection chart in home
  $('#collections-charts').easyPieChart({
        animate: 1000,
        size: 70,
        barColor:'#a979d1'
    });

    $('#storage-charts').easyPieChart({
          animate: 1000,
          size: 70,
          barColor:'#53d192'
      });

      // This helper present in slicklab script.js
      collapseChartContent();
});
