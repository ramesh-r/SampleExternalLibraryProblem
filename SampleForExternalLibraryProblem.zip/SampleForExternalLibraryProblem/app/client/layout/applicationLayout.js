//-----------------------------------------------------------------------
// <copyright file="applicationLayout.js" company="Anecom Inc">
// Copyright (c) Anecom Inc. All rights reserved. 2015.
// </copyright>
//-----------------------------------------------------------------------

Template.applicationLayout.helpers({
});

Template.applicationLayout.onRendered(function(){
  $("body").removeAttr('style');
      $("html").niceScroll({
        styler: "fb",
        cursorcolor: "#a979d1",
        cursorwidth: '5',
        cursorborderradius: '15px',
        background: '#404040',
        cursorborder: '',
        zindex: '12000'
    });
});

Template.applicationLayout.events({
  'click .toggle-btn': function (event) {
      var body = jQuery('body');
      var bodyposition = body.css('position');

      if(bodyposition != 'relative') {
         if(!body.hasClass('sidebar-collapsed')) {
            body.addClass('sidebar-collapsed');
            jQuery('.side-navigation ul').attr('style','');

         } else {
            body.removeClass('sidebar-collapsed chat-view');
            jQuery('.side-navigation li.active ul').css({display: 'block'});

         }
      } else {

         if(body.hasClass('sidebar-open'))
            body.removeClass('sidebar-open');
         else
            body.addClass('sidebar-open');
      }
  }
});
